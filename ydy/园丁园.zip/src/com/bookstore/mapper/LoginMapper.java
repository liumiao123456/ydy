package com.bookstore.mapper;
 
//import org.springframework.stereotype.Mapper;
 
import com.bookstore.dao.User;
 

public interface LoginMapper {
	User login(String name, String pwd);
 
}
