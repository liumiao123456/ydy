package com.bookstore.mapper;
import org.springframework.stereotype.Repository;
import com.bookstore.dao.User;
 

public interface RegisterMapper {
	//定义注册的所有接口
	int register(User user);
 
	int getUserByNameAndPwd(User user);
 
}
