package com.bookstore.mapper;
 
import java.util.List;
 
//import org.springframework.stereotype.Mapper;
 
import com.bookstore.dao.Cart;
 
public interface CartMapper {
	
	int incart(Cart cart);
 
	List<Cart> getAllOrders(String orderman);
 
	int deleteCartById(int id);
 
}
