package com.bookstore.mapper;


import java.util.List;

import com.bookstore.dao.Book;
 

public interface BookMapper {
 
	
	List<Book> getAllNewBooks();
 
    List<Book> getAllBooks();
 
	Book getBookById(int id);
 
	List<Book> getBooksByBooktype(int type);
 
}
