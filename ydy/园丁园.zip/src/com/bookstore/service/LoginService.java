package com.bookstore.service;

public class LoginService {

}
