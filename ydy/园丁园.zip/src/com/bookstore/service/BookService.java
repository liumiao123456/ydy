package com.bookstore.service;

public class BookService {

}
