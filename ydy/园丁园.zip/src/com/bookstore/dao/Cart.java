package com.bookstore.dao;


import java.util.Date;
 
import org.springframework.format.annotation.DateTimeFormat;
 
public class Cart{
	private int id;
	private String name;
	private int count;
	private double price;
	@DateTimeFormat (pattern = "yy-MM-dd")
	private Date date;
	private String orderman;
       /*    get,set     */
}
