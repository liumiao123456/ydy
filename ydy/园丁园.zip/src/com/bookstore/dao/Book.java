package com.bookstore.dao;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;
 
public class Book {
	private int id;
	private String name;
	private String author;//作者
	private String press; 
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date pubdate; 
	private Double price; //价格
	private int page; //页数
	private String img;// 图片
	private String feature;
	private int booktype;
/*     这里写get，set方法     */
}
